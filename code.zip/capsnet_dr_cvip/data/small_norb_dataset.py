import os.path
import torchvision.transforms as transforms
from data.base_dataset import BaseDataset, get_smallnorb_transform
from data.image_folder import make_dataset
from data.process_smallnorb import  SmallNORBDataset
from PIL import Image
import PIL
import random
import numpy
import numpy.random
numpy.random.seed(420)

'''
This database is intended for experiments in 3D object reocgnition from shape. It contains images of 50 toys belonging to 5 generic categories: four-legged animals, human figures, airplanes, trucks, and cars. The objects were imaged by two cameras under 6 lighting conditions, 9 elevations (30 to 70 degrees every 5 degrees), and 18 azimuths (0 to 340 every 20 degrees).

The training set is composed of 5 instances of each category (instances 4, 6, 7, 8 and 9), and the test set of the remaining 5 instances (instances 0, 1, 2, 3, and 5). 
'''

class SmallNorbDataset(BaseDataset):
    def initialize(self, opt):
        # Introducing 75-25 train-test split
        category = 0
        self.opt = opt
        self.root = opt.dataroot
        smallnorb_dataset = SmallNORBDataset(dataset_root= self.root)
        img_dataset_train = smallnorb_dataset.group_dataset_by_category_and_instance('train')
        #img_dataset_test = smallnorb_dataset.group_dataset_by_category_and_instance('test')
        self.img_dataset = (img_dataset_train)[category]
        numpy.random.shuffle(self.img_dataset)


        if(opt.phase == 'train'):
            self.img_dataset = self.img_dataset[:648]
        else:
            self.img_dataset = self.img_dataset[648:]
        '''
        for i in range(100):
            print(self.img_dataset[i].pose())
        '''
    
        self.A_size = len(self.img_dataset)
        self.A_poses = []
        for img in self.img_dataset:
            
            elevation  = 30 + 5*img.elevation
            azimuth = img.azimuth*10  

            '''
            elevation  = (30 + 5*img.elevation)/90
            azimuth = img.azimuth*10/360
            '''

            self.A_poses.append([elevation, azimuth])
        self.A_poses = numpy.asarray(self.A_poses)

        self.mean_image = None
        print("mean image subtraction is deactivated")
        self.transform = get_smallnorb_transform(opt, self.mean_image)

        '''
        split_file = os.path.join(self.root , 'dataset_'+opt.phase+'.txt')
        self.A_paths = numpy.loadtxt(split_file, dtype=str, delimiter=' ', skiprows=3, usecols=(0))
        self.A_paths = [os.path.join(self.root, path) for path in self.A_paths]
        self.A_poses = numpy.loadtxt(split_file, dtype=float, delimiter=' ', skiprows=3, usecols=(1,2,3,4,5,6,7))
        self.mean_image = numpy.load(os.path.join(self.root , 'mean_image.npy'))
        '''


    def __getitem__(self, index):
        index_A = index % self.A_size
        # print('(A, B) = (%d, %d)' % (index_A, index_B))
        imgarr = self.img_dataset[index_A].img_arr()
        # print(imgarr)
        A_img = Image.fromarray(imgarr, 'L')
        #A_img.save("sample_img_pre_transformation.jpg")
        A = self.transform(A_img)
        '''
        im = Image.fromarray(A.numpy(), 'L') 
        im.save("sample_img_pre_transformation.jpg") 
        '''       
        A_pose = self.A_poses[index_A]
        return {'A': A, 'B': A_pose}

    def __len__(self):
        return self.A_size

    def name(self):
        return 'SmallNorbDataset'
