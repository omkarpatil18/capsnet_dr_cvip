import cv2
import matplotlib.pyplot as plt
from cv2 import resize
import matplotlib.gridspec as gridspec
from math import ceil
from torch.autograd import Variable
from PIL import Image
import numpy as np
import torch
from pdb import set_trace
# from scipy import ndimage

from options.test_options import TestOptions
from models.models import create_model
from data.base_dataset import get_vis_transform

opt = TestOptions().parse()
testepoch = 275

'''
Extend later to generate images from noise which yield specific values of pose vector
For CapsNet: to optmise loss for a capsules rather than layer filters
'''

class SaveFeatures():
    def __init__(self, module):
        self.hook = module.register_forward_hook(self.hook_fn)
    def hook_fn(self, module, input, output):
        self.features = output
    def close(self):
        self.hook.remove()

class FilterVisualizer():
    def __init__(self):
        self.model = create_model(opt)
        self.model.load_network(self.model.netG, 'G', testepoch)
        self.transform = get_vis_transform(opt, None)

    def visualize(self, sz, layer_idx, filter, upscaling_steps=12, upscaling_factor=1.2, lr=0.1, opt_steps=20, blur=None, save=False, print_losses=True):

        all_layers = dict(self.model.named_params())
        print(all_layers)
        print("***********")
        layer = all_layers['conv1']
        activations = SaveFeatures(layer)  # register hook

        img = np.random.randint(0, 255, size=(sz, sz), dtype=np.uint8)

        for i in range(upscaling_steps):  # scale the image up upscaling_steps times
            img = Image.fromarray(img, 'L')
            img_var = Variable(self.transform(img)[None], requires_grad=True)    # convert image to Variable that requires grad
            optimizer = torch.optim.Adam([img_var], lr=lr, weight_decay=1e-6)
            if i > upscaling_steps/2:
                opt_steps_ = int(opt_steps*1.3)
            else:
                opt_steps_ = opt_steps

            for n in range(opt_steps_):  # optimize pixel values for opt_steps times
                optimizer.zero_grad()
                self.model.forward(img_var)

                loss = -activations.features[0, filter].mean()
                if print_losses:
                    print(f'{i} - {n} - {float(loss)}')
                loss.backward()
                optimizer.step()

            img = np.squeeze(img_var.cpu().detach().numpy())
            self.output = img
            sz = int(upscaling_factor * sz)  # calculate new image size
            img = cv2.resize(img, (sz, sz), interpolation = cv2.INTER_CUBIC)  # scale image up
            #if blur is not None: img = cv2.blur(img,(blur,blur))  # blur image to reduce high frequency patterns
        if save:
            self.save(layer, filter)
        activations.close()
        return self.output
    
    def most_activated(self, image, layer_idx, limit_top=None):

        img = Image.fromarray(image, 'L') 
        transformed = self.transform(img)
        all_layers = dict(self.model.named_params())
        layer = all_layers['conv1']
        activations = SaveFeatures(layer)  # register hook
        self.model(Variable(transformed)[None])
        mean_act = [activations.features[0,i].mean().data.cpu().numpy()[0] for i in range(activations.features.shape[1])]
        activations.close()
        return mean_act


def plot_reconstructions(imgs,layer_idx,filters,n_cols=3, cell_size=4):
    n_rows = ceil((len(imgs))/n_cols)

    fig,axes = plt.subplots(n_rows,n_cols, figsize=(cell_size*n_cols,cell_size*n_rows))
          
    for i,ax in enumerate(axes.flat):
        ax.grid(False)
        ax.get_xaxis().set_visible(False)
        ax.get_yaxis().set_visible(False)

        if i>=len(filters):
            pass

        ax.set_title(f'fmap {filters[i]}')

        ax.imshow(imgs[i],cmap='gray', vmin=0, vmax=255)

    fig.suptitle(f'Layer: {layer_idx}', fontsize="x-large",y=1.0)
    plt.tight_layout()
    plt.subplots_adjust(top=0.9)
    plt.show()
    
def reconstructions(layer_idx, filters,
                    init_size=48, upscaling_steps=1, 
                    upscaling_factor=1, 
                    opt_steps=500, blur=5,
                    lr=1e-1,print_losses=False,
                    n_cols=3, cell_size=4):
    
    imgs = []
    for filter in filters:
        imgs.append(FV.visualize(init_size,layer_idx, filter, 
                                    upscaling_steps=upscaling_steps, 
                                    upscaling_factor=upscaling_factor, 
                                    opt_steps=opt_steps, blur=blur,
                                    lr=lr,print_losses=print_losses))
        
    return plot_reconstructions(imgs,layer_idx,filters,
                         n_cols=n_cols,cell_size=cell_size)

import requests
import base64
import pprint


FV = FilterVisualizer()
reconstructions(layer_idx=1,filters=list(range(6)))

# import os.path
# import torchvision.transforms as transforms
# from data.base_dataset import BaseDataset, get_smallnorb_transform
# from data.image_folder import make_dataset
# from data.process_smallnorb import  SmallNORBDataset
# from PIL import Image
# import PIL
# import random
# import numpy
# import numpy.random
# numpy.random.seed(420)


# category = 0
# root = opt.dataroot
# smallnorb_dataset = SmallNORBDataset(dataset_root= root)
# img_dataset_train = smallnorb_dataset.group_dataset_by_category_and_instance('train')
# #img_dataset_test = smallnorb_dataset.group_dataset_by_category_and_instance('test')
# img_dataset = (img_dataset_train)[category]
# numpy.random.shuffle(img_dataset)



# def plot_reconstruction (imgs,n_cols=4, cell_size=4):
#     n_rows = ceil((len(imgs))/n_cols)

#     fig,axes = plt.subplots(n_rows,n_cols, figsize=(cell_size*n_cols,cell_size*n_rows))
          
#     for i,ax in enumerate(axes.flat):
#         ax.grid(False)
#         ax.get_xaxis().set_visible(False)
#         ax.get_yaxis().set_visible(False)

#         ax.imshow(imgs[i])

#     plt.tight_layout()
#     plt.subplots_adjust(top=0.9)
#     plt.savefig("duhh.png")


# A_size = len(img_dataset)
# img_arr = []

# for index in range(16):
#     index_A = index % A_size
#     # print('(A, B) = (%d, %d)' % (index_A, index_B))
#     imgarr = img_dataset[index_A].img_arr()
#     # print(imgarr)
#     A_img = Image.fromarray(imgarr, 'L')
#     img_arr.append(A_img)

# plot_reconstruction(img_arr)
