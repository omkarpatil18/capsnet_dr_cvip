import time
from options.train_options import TrainOptions
from data.data_loader import CreateDataLoader
from models.models import create_model
from util.visualizer import Visualizer

opt = TrainOptions().parse()
## SEEDING
import torch
import numpy
import random
torch.manual_seed(opt.seed)
numpy.random.seed(opt.seed)
random.seed(opt.seed)
# torch.backends.cudnn.enabled = False
torch.backends.cudnn.deterministic = True
## SEEDING

data_loader = CreateDataLoader(opt)
dataset = data_loader.load_data()
dataset_size = len(data_loader)
print('#training images = %d' % dataset_size)

model = create_model(opt)
visualizer = Visualizer(opt)
total_steps = 0

for epoch in range(opt.epoch_count, opt.niter + opt.niter_decay + 1):
    epoch_start_time = time.time()
    epoch_iter = 0

    for i, data in enumerate(dataset):
        iter_start_time = time.time()
        visualizer.reset()
        total_steps += opt.batchSize
        epoch_iter += opt.batchSize
        model.set_input(data)
        model.optimize_parameters()

        # if total_steps % opt.display_freq == 0:
        #     save_result = total_steps % opt.update_html_freq == 0
        #     visualizer.display_current_results(model.get_current_visuals(), epoch, save_result)

        if total_steps % opt.print_freq == 0:
            errors = model.get_current_errors()
            t = (time.time() - iter_start_time) / opt.batchSize
            visualizer.print_current_errors(epoch, epoch_iter, errors, t)
            if opt.display_id > 0:
                visualizer.plot_current_errors(epoch, float(epoch_iter)/dataset_size, opt, errors)

        # if total_steps % opt.save_latest_freq == 0:
        #     print('saving the latest model (epoch %d, total_steps %d)' %
        #           (epoch, total_steps))
        #     model.save('latest')

    if epoch % opt.save_epoch_freq == 0:
        print('saving the model at the end of epoch %d, iters %d' %
              (epoch, total_steps))
        model.save('latest')
        model.save(epoch)

    print('End of epoch %d / %d \t Time Taken: %d sec' %
          (epoch, opt.niter + opt.niter_decay, time.time() - epoch_start_time))
    model.update_learning_rate()

# On server:
# PoseNet
# python train.py --init_weights '' --model posenet --dataroot /media/data2/intern/omkar/datasets/smallnorb/dataset --name posenet/smallnorb/1 --gpu 0 --loadSize 256 --fineSize 224 --input_nc 1 --nThreads 2 --dataset_mode small_norb --batchSize 54 --niter 1500 --lr 0.005
# python test.py --model posenet  --dataroot /media/data2/intern/omkar/datasets/smallnorb/dataset --name posenet/smallnorb/3 --gpu 0 --loadSize 256 --fineSize 224 --input_nc 1 --nThreads 2 --dataset_mode small_norb
# python train.py --init_weights '' --checkpoints_dir /media/data2/intern/omkar/pytorch_models/checkpoints --model posenet --dataroot /media/data2/intern/omkar/datasets/smallnorb/dataset --name posenet/smallnorb/3 --gpu 0 --loadSize 256 --fineSize 224 --input_nc 1 --nThreads 2 --dataset_mode small_norb --batchSize 54 --niter 500 --continue_train --which_epoch 2500 --lr 0.0001


# CapsNet
# python train.py --init_weights '' --model capsnet_dr --dataroot /media/data2/intern/omkar/datasets/smallnorb/dataset --name capsnet/smallnorb/3 --gpu 0 --loadSize 48 --input_nc 1 --nThreads 2 --dataset_mode small_norb --batchSize 54 --niter 500 --lr 0.0001
# python test.py --model capsnet_dr  --dataroot /media/data2/intern/omkar/datasets/smallnorb/dataset --name capsnet/smallnorb/3 --gpu 0 --loadSize 48 --input_nc 1 --nThreads 2 --dataset_mode small_norb
# python train.py --init_weights '' --checkpoints_dir /media/data2/intern/omkar/pytorch_models/checkpoints --model capsnet_dr --dataroot /media/data2/intern/omkar/datasets/smallnorb/dataset --name capsnet/smallnorb/2 --gpu 0 --loadSize 48 --input_nc 1 --nThreads 2 --dataset_mode small_norb --batchSize 54 --niter 500 --continue_train --which_epoch 2500 --lr 0.0001

# On PC:
# python train.py --model poselstm --dataroot /home/omkar/ddp/datasets/smallnorb/dataset --name poselstm/smallNorb/beta500 --beta 500 --niter 1 --gpu 0 --input_nc 1 --init_weights '' --loadSize 224 --dataset_mode small_norb
# python test.py --model posenet --dataroot /home/omkar/ddp/datasets/smallnorb/dataset --name posenet/smallNorb/beta500 --beta 500 --niter 1 --gpu 0 --input_nc 1 --init_weights '' --loadSize 224 --dataset_mode small_norb

# vis
# python img_for_max_filter.py --model posenet  --dataroot /home/omkar/ddp/datasets/smallnorb/dataset --name posenet/small_norb/2 --gpu 0 --loadSize 256 --fineSize 224 --input_nc 1 --dataset_mode small_norb --batchSize 1
# python img_for_max_filter.py --model capsnet_dr  --dataroot /home/omkar/ddp/datasets/smallnorb/dataset --name capsnet/small_norb/1 --gpu 0 --loadSize 48 --fineSize 48 --input_nc 1 --dataset_mode small_norb --batchSize 1 --output_nc 2


# python train.py --init_weights '' --model capsnet_dr --dataroot /media/data2/omkar/datasets/smallnorb/dataset --name capsnet/smallnorb/1 --gpu 0 --loadSize 48 --input_nc 1 --nThreads 2 --dataset_mode small_norb --batchSize 54 --niter 3000 --lr 0.0001