"""
Dynamic Routing Between Capsules
https://arxiv.org/abs/1710.09829

PyTorch implementation by Omkar Patil.
Inspired from Kenta Iwasaki @ Gram.AI
"""
import numpy as np
import torch
import torch.nn.functional as F
import os
from collections import OrderedDict
from torch.autograd import Variable
import util.util as util
from util.image_pool import ImagePool
from .base_model import BaseModel
from . import networks

class CapsNetModel(BaseModel):
    def name(self):
        return 'CapsNetModel_DynamicRouting'
    
    def named_params(self):
        layers = list(self.netG.named_children())
        return layers

    def initialize(self, opt):
        BaseModel.initialize(self, opt)
        self.isTrain = opt.isTrain
        # define tensors
        self.input_A = self.Tensor(opt.batchSize, opt.input_nc,
                                   opt.fineSize, opt.fineSize)
        self.input_B = self.Tensor(opt.batchSize, opt.output_nc)

#       self.mean_image = np.load(os.path.join(opt.dataroot, 'mean_image.npy'))

        self.netG = networks.define_network(opt.input_nc, None, opt.model,
                                      init_from=None, isTest=not self.isTrain,
                                      gpu_ids= self.gpu_ids)

        if not self.isTrain or opt.continue_train:
            self.load_network(self.netG, 'G', opt.which_epoch)

        if self.isTrain:
            self.old_lr = opt.lr
            # define loss functions
            self.criterion = torch.nn.MSELoss()

            # initialize optimizers
            self.schedulers = []
            self.optimizers = []
            self.optimizer_G = torch.optim.Adam(self.netG.parameters(),
                                                lr=opt.lr, eps=1,
                                                weight_decay=0.0625,
                                                betas=(self.opt.adambeta1, self.opt.adambeta2))
            
            self.optimizers.append(self.optimizer_G)
            # for optimizer in self.optimizers:
            #     self.schedulers.append(networks.get_scheduler(optimizer, opt))

        print('---------- Networks initialized -------------')
        # networks.print_network(self.netG)
        # print('-----------------------------------------------')

    def set_input(self, input):

        input_A = input['A']
        input_B = input['B']
        #self.image_paths = input['A_paths']
        self.input_A.reshape(input_A.size()).copy_(input_A)
        self.input_B.reshape(input_B.size()).copy_(input_B)

    def forward(self, inp_A):
        self.pred_B = self.netG(inp_A)
        
        '''
        self.pred_B = self.netG(self.input_A)
        
        #self.pred_B[:,0] = self.pred_B[:,0]*90
        #self.pred_B[:,1] = self.pred_B[:,1]*360
        
        self.pred_B[0] = self.pred_B[0]*90
        self.pred_B[1] = self.pred_B[1]*360
        '''

    # no backprop gradients
    def test(self):
        self.forward()

    '''
    # get image paths
    def get_image_paths(self):
        return self.image_paths
    '''

    def backward(self):
        '''
        pos_gt = F.normalize(self.input_B[:, :3], p=2, dim=1)
        mse_pos = self.criterion(F.normalize(self.pred_B[:, :3], p=2, dim=1), pos_gt)
        ori_gt = F.normalize(self.input_B[:, 3:], p=2, dim=1)
        mse_ori = self.criterion(F.normalize(self.pred_B[:, 3:], p=2, dim=1), ori_gt)
        self.loss_G = (mse_pos + mse_ori) * self.opt.beta 
        self.loss_pos = mse_pos.item() * self.opt.beta
        self.loss_ori = mse_ori.item() * self.opt.beta
        self.loss_G.backward()
        '''
        self.loss = self.criterion(self.pred_B, self.input_B)
        self.loss.backward()

    def optimize_parameters(self):
        self.forward()
        self.optimizer_G.zero_grad()
        self.backward()
        #plot_grad_flow(model.named_parameters())
        self.optimizer_G.step()

    def get_current_errors(self):

        '''
        if self.opt.isTrain:
            return OrderedDict([('pos_err', self.loss_pos),
                                ('ori_err', self.loss_ori),
                                ])

        pos_gt = F.normalize(self.input_B[:, :3], p=2, dim=1)
        abs_dist_pos = torch.abs((pos_gt.mul(F.normalize(self.pred_B[:, :3], p=2, dim=1))).sum())
        pos_err = 2*180/numpy.pi* torch.acos(abs_dist_pos)


        ori_gt = F.normalize(self.input_B[:, 3:], p=2, dim=1)
        abs_distance = torch.abs((ori_gt.mul(F.normalize(self.pred_B[:, 3:], p=2, dim=1))).sum())
        ori_err = 2*180/numpy.pi* torch.acos(abs_distance)

        return [pos_err.item(), ori_err.item()]
        '''
        if self.opt.isTrain:
            return OrderedDict([('err', self.loss.item())])
        err = torch.dist(self.pred_B, self.input_B)
        return [err.item()]

    def get_current_pose(self):
        '''
        return numpy.concatenate((F.normalize(self.pred_B[:, :3], p=2, dim=1).data[0].cpu().numpy(),
                                  F.normalize(self.pred_B[:, 3:], p=2, dim=1).data[0].cpu().numpy()))
        '''
        #return self.pred_B[0].data[0].cpu().numpy()
        return self.pred_B.detach().cpu().numpy()


    def get_current_visuals(self):
        input_A = util.tensor2im(self.input_A.data)
        # pred_B = util.tensor2im(self.pred_B.data)
        # input_B = util.tensor2im(self.input_B.data)
        return OrderedDict([('input_A', input_A)])

    def save(self, label):
        self.save_network(self.netG, 'G', label, self.gpu_ids)

    def plot_grad_flow(named_parameters):
        '''Plots the gradients flowing through different layers in the net during training.
        Can be used for checking for possible gradient vanishing / exploding problems.
        
        Usage: Plug this function in Trainer class after loss.backwards() as 
        "plot_grad_flow(self.model.named_parameters())" to visualize the gradient flow'''
        ave_grads = []
        max_grads= []
        layers = []
        for n, p in named_parameters:
            if(p.requires_grad) and ("bias" not in n):
                layers.append(n)
                ave_grads.append(p.grad.abs().mean())
                max_grads.append(p.grad.abs().max())
        plt.bar(np.arange(len(max_grads)), max_grads, alpha=0.1, lw=1, color="c")
        plt.bar(np.arange(len(max_grads)), ave_grads, alpha=0.1, lw=1, color="b")
        plt.hlines(0, 0, len(ave_grads)+1, lw=2, color="k" )
        plt.xticks(range(0,len(ave_grads), 1), layers, rotation="vertical")
        plt.xlim(left=0, right=len(ave_grads))
        plt.ylim(bottom = -0.001, top=0.02) # zoom in on the lower gradient regions
        plt.xlabel("Layers")
        plt.ylabel("average gradient")
        plt.title("Gradient flow")
        plt.grid(True)
        plt.legend([Line2D([0], [0], color="c", lw=4),
                    Line2D([0], [0], color="b", lw=4),
                    Line2D([0], [0], color="k", lw=4)], ['max-gradient', 'mean-gradient', 'zero-gradient'])
