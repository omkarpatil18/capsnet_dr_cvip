import cv2
import matplotlib.pyplot as plt
from cv2 import resize
import matplotlib.gridspec as gridspec
from math import ceil
from torch.autograd import Variable
from PIL import Image
import numpy as np
import torch
from pdb import set_trace
# from scipy import ndimage

from options.test_options import TestOptions
from models.models import create_model
from data.base_dataset import get_vis_transform

opt = TestOptions().parse()
testepoch = 275

'''
Extend later to generate images from noise which yield specific values of pose vector
'''

class SaveFeatures():
    def __init__(self, module):
        self.hook = module.register_forward_hook(self.hook_fn)
    def hook_fn(self, module, input, output):
        self.features = output
    def close(self):
        self.hook.remove()

class FilterVisualizer():
    def __init__(self):
        self.model = create_model(opt)
        self.model.load_network(self.model.netG, 'G', testepoch)
        self.transform = get_vis_transform(opt, None)

    def visualize(self, sz, layer_idx, filter, upscaling_steps=12, upscaling_factor=1.2, lr=0.1, opt_steps=20, blur=None, save=False, print_losses=True):

        all_layers = dict(self.model.named_params())
        layer = all_layers['conv1']
        activations = SaveFeatures(layer)  # register hook

        img = np.random.randint(0, 255, size=(sz, sz), dtype=np.uint8)

        for i in range(upscaling_steps):  # scale the image up upscaling_steps times
            img = Image.fromarray(img, 'L')
            img_var = Variable(self.transform(img)[None], requires_grad=True)    # convert image to Variable that requires grad
            optimizer = torch.optim.Adam([img_var], lr=lr, weight_decay=1e-6)
            if i > upscaling_steps/2:
                opt_steps_ = int(opt_steps*1.3)
            else:
                opt_steps_ = opt_steps

            for n in range(opt_steps_):  # optimize pixel values for opt_steps times
                optimizer.zero_grad()
                self.model.forward(img_var)

                loss = -activations.features[0, filter].mean()
                if print_losses:
                    print(f'{i} - {n} - {float(loss)}')
                loss.backward()
                optimizer.step()

            img = np.squeeze(img_var.cpu().detach().numpy())
            self.output = img
            sz = int(upscaling_factor * sz)  # calculate new image size
            img = cv2.resize(img, (sz, sz), interpolation = cv2.INTER_CUBIC)  # scale image up
            #if blur is not None: img = cv2.blur(img,(blur,blur))  # blur image to reduce high frequency patterns
        if save:
            self.save(layer, filter)
        activations.close()
        return self.output
    
    def most_activated(self, image, layer_idx, limit_top=None):

        transformed = self.transform(img)
        all_layers = dict(self.model.named_params())
        layer = all_layers['conv1']
        activations = SaveFeatures(layer)  # register hook
        self.model(Variable(transformed)[None])
        mean_act = [activations.features[0,i].mean().data.cpu().numpy()[0] for i in range(activations.features.shape[1])]
        activations.close()
        return mean_act

    def get_transformed_img(self,img):
        return self.transform(img)


def plot_reconstructions(imgs,layer_idx,filters,n_cols=3, cell_size=4):
    n_rows = ceil((len(imgs))/n_cols)

    fig,axes = plt.subplots(n_rows,n_cols, figsize=(cell_size*n_cols,cell_size*n_rows))
          
    for i,ax in enumerate(axes.flat):
        ax.grid(False)
        ax.get_xaxis().set_visible(False)
        ax.get_yaxis().set_visible(False)

        if i>=len(filters):
            pass

        ax.set_title(f'fmap {filters[i]}')

        ax.imshow(imgs[i],cmap='gray', vmin=0, vmax=255)

    fig.suptitle(f'Layer: {layer_idx}', fontsize="x-large",y=1.0)
    plt.tight_layout()
    plt.subplots_adjust(top=0.9)
    plt.show()
    
def reconstructions(layer_idx, filters,
                    init_size=48, upscaling_steps=12, 
                    upscaling_factor=1.2, 
                    opt_steps=500, blur=5,
                    lr=1e-1,print_losses=False,
                    n_cols=3, cell_size=4):
    
    imgs = []
    for filter in filters:
        imgs.append(FV.visualize(init_size,layer_idx, filter, 
                                    upscaling_steps=upscaling_steps, 
                                    upscaling_factor=upscaling_factor, 
                                    opt_steps=opt_steps, blur=blur,
                                    lr=lr,print_losses=print_losses))
        
    return plot_reconstructions(imgs,layer_idx,filters,
                         n_cols=n_cols,cell_size=cell_size)

import requests
import base64
import pprint


def plot_activations_and_reconstructions(imgs,activations,filters,
                                         transformed_img,n_cols=3,
                                         cell_size=4,layer_name=''):
    n_rows = ceil((len(imgs)+1)/n_cols)

    fig = plt.figure(figsize=(cell_size*n_cols,cell_size*n_rows))
    gs = gridspec.GridSpec(n_rows, n_cols)
    tr_im_ax = plt.subplot(gs[0,0])
    tr_im_ax.grid(False)
    tr_im_ax.get_xaxis().set_visible(False)
    tr_im_ax.get_yaxis().set_visible(False)
    tr_im_ax.imshow(transformed_img)
    tr_im_ax.set_title('Image')
    
    act_ax = plt.subplot(gs[0, 1:])
    
    
    act = act_ax.plot(np.clip(activations,0.,None),linewidth=2.)
    for el in filters:
        act_ax.axvline(x=el, color='red', linestyle='--',alpha=0.4)
    act_ax.set_xlim(0,len(activations));
    act_ax.set_ylabel(f"mean activation");
    if layer_name == '':
        act_ax.set_title('Mean Activations')
    else:
        act_ax.set_title(f'{layer_name}')
    act_ax.set_facecolor('white')
    
    fmap_axes = []
    for r in range(1,n_rows):
        for c in range(n_cols):
            fmap_axes.append(plt.subplot(gs[r, c]))
            
    for i,ax in enumerate(fmap_axes):
        ax.grid(False)
        ax.get_xaxis().set_visible(False)
        ax.get_yaxis().set_visible(False)

        if i>=len(filters):
            pass

        ax.set_title(f'fmap {filters[i]}')

        ax.imshow(imgs[i])
    plt.tight_layout()
    save_name = layer_name.lower().replace(' ','_')
    plt.show()


def activations_and_reconstructions(img,activation_layer,fmap_layer,
                                    top_num=4,init_size=48,
                                    upscaling_steps=1, upscaling_factor=1,
                                    opt_steps=20, blur=5,lr=1e-1,
                                    n_cols=3, cell_size=4,
                                    layer_name=''):

    FV = FilterVisualizer()
    mean_acts = FV.most_activated(img,layer = activation_layer)

    most_act_fmaps = sorted(range(len(mean_acts)), key=lambda i: mean_acts[i])[-top_num:][::-1]

    imgs = []
    for filter in most_act_fmaps:
        imgs.append(FV.visualize(init_size,fmap_layer, filter, upscaling_steps=upscaling_steps, 
                                 upscaling_factor=upscaling_factor, 
                                 opt_steps=opt_steps, blur=blur,
                                 lr=lr,print_losses=False))
    transformed_img = FV.get_transformed_img(img)
    
    return plot_activations_and_reconstructions(imgs,mean_acts,
                                         most_act_fmaps,transformed_img,
                                         n_cols=n_cols,cell_size=cell_size,
                                         layer_name=layer_name)

from os import listdir
from PIL import Image as PImage

def loadImages(path):
    # return array of images

    imagesList = listdir(path)
    loadedImages = []
    for image in imagesList:
        img = PImage.open(path + image)
        loadedImages.append(img)

    return loadedImages

path = "/home/omkar/ddp/graphics/smallnorb_imgs"

# your images in an array
imgs = loadImages(path)

for img in imgs:
    # you can show every image
    activations_and_reconstructions(img,40,2,top_num=3,
                                layer_name='CapsNet Conv1',
                                save_fig=False)

